des 파일 실헹

```
g++ -o main des.cpp main.cpp
```

Chat system
```
./make.sh
```

Start Server 
```
./build/server
```

Start Client
```
./build/client [user name]
```