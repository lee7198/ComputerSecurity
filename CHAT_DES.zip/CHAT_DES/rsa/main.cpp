#include <iostream>
using namespace std;

int main() {
    char* a = "HELLO";
    cout << a << endl;
    a = "HI";
    cout << a << endl;
}